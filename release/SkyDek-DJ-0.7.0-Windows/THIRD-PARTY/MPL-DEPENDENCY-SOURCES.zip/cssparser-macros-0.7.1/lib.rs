/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

extern crate proc_macro;

use proc_macro::TokenStream;

fn get_byte_from_lit(lit: &syn::Lit) -> u8 {
    if let syn::Lit::Byte(ref byte) = *lit {
        byte.value()
    } else {
        panic!("Found a pattern that wasn't a byte")
    }
}

fn get_byte_from_expr_lit(expr: &syn::Expr) -> u8 {
    match *expr {
        syn::Expr::Lit(syn::ExprLit { ref lit, .. }) => get_byte_from_lit(lit),
        _ => unreachable!(),
    }
}

/// Parse a pattern and fill the table accordingly
fn parse_pat_to_table<'a>(
    pat: &'a syn::Pat,
    case_id: u8,
    wildcard: &mut Option<&'a syn::Ident>,
    table: &mut [Option<u8>; 256],
) {
    match pat {
        syn::Pat::Lit(syn::PatLit { ref lit, .. }) => {
            let value = get_byte_from_lit(lit);
            table[value as usize].get_or_insert(case_id);
        }
        syn::Pat::Range(syn::PatRange {
            ref start, ref end, ..
        }) => {
            let lo = get_byte_from_expr_lit(start.as_ref().unwrap());
            let hi = get_byte_from_expr_lit(end.as_ref().unwrap());
            for value in lo..hi {
                table[value as usize].get_or_insert(case_id);
            }
            table[hi as usize].get_or_insert(case_id);
        }
        syn::Pat::Wild(_) => {
            for byte in table.iter_mut() {
                byte.get_or_insert(case_id);
            }
        }
        syn::Pat::Ident(syn::PatIdent { ref ident, .. }) => {
            assert_eq!(*wildcard, None);
            *wildcard = Some(ident);
            for byte in table.iter_mut() {
                byte.get_or_insert(case_id);
            }
        }
        syn::Pat::Or(syn::PatOr { ref cases, .. }) => {
            for case in cases {
                parse_pat_to_table(case, case_id, wildcard, table);
            }
        }
        _ => {
            panic!("Unexpected or unsupported pattern: {:?}. Buggy code ?", pat);
        }
    }
}

/// Expand a TokenStream corresponding to the `match_byte` macro.
///
/// ## Example
///
/// ```rust,ignore
/// match_byte! { tokenizer.next_byte_unchecked(),
///     b'a'..b'z' => { ... }
///     b'0'..b'9' => { ... }
///     b'\n' | b'\\' => { ... }
///     foo => { ... }
///  }
///  ```
///
#[proc_macro]
pub fn match_byte(input: TokenStream) -> TokenStream {
    use syn::spanned::Spanned;
    struct MatchByte {
        expr: syn::Expr,
        arms: Vec<syn::Arm>,
    }

    impl syn::parse::Parse for MatchByte {
        fn parse(input: syn::parse::ParseStream) -> syn::Result<Self> {
            Ok(MatchByte {
                expr: {
                    let expr = input.parse()?;
                    input.parse::<syn::Token![,]>()?;
                    expr
                },
                arms: {
                    let mut arms = Vec::new();
                    while !input.is_empty() {
                        let arm = input.call(syn::Arm::parse)?;
                        assert!(
                            arm.attrs.is_empty(),
                            "match_byte doesn't support attributes"
                        );
                        arms.push(arm);
                    }
                    arms
                },
            })
        }
    }
    let MatchByte { expr, arms } = syn::parse_macro_input!(input);

    let mut cases = Vec::new();
    let mut table = [None; 256];
    let mut match_body = Vec::new();
    let mut wildcard = None;
    for (i, ref arm) in arms.iter().enumerate() {
        let case_id = i as isize;
        let name = syn::Ident::new(&format!("Case{case_id}"), arm.span());
        let pat = &arm.pat;
        parse_pat_to_table(pat, i as u8, &mut wildcard, &mut table);

        cases.push(quote::quote!(#name = #case_id));
        let body = &arm.body;
        match_body.push(quote::quote!(Case::#name => { #body }))
    }

    let en = quote::quote!(enum Case {
        #(#cases),*
    });

    let mut table_content = Vec::new();
    for (byte, entry) in table.iter().enumerate() {
        let case_id = match entry {
            Some(id) => id,
            None => panic!("Uncovered byte {:?} (add a wildcard pattern?)", byte),
        };
        let name: syn::Path = syn::parse_str(&format!("Case::Case{case_id}")).unwrap();
        table_content.push(name);
    }
    let table = quote::quote!(static __CASES: [Case; 256] = [#(#table_content),*];);

    if let Some(binding) = wildcard {
        quote::quote!({ #en #table let #binding = #expr; match __CASES[#binding as usize] { #(#match_body),* }})
    } else {
        quote::quote!({ #en #table match __CASES[#expr as usize] { #(#match_body),* }})
    }.into()
}

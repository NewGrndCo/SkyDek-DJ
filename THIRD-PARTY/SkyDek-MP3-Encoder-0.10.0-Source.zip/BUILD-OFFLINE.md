# Build the separate MP3 encoder

This archive contains only the MIT-licensed encoder helper's authored source,
its full locked vendored dependencies, native LAME C source and upstream licenses.
Dependency licenses apply to their own files. Proprietary SkyDek DJ source is excluded.

On Windows x64 install Rust (MSVC host) and Visual Studio C++ Build Tools with a
Windows SDK. A Rust toolchain meeting every locked dependency's rust-version is
required; toolchains and the Windows SDK are not vendored. From this extracted
directory, with no network access required by Cargo:

    cargo metadata --offline --locked --format-version 1
    cargo build --release --offline --locked --target x86_64-pc-windows-msvc

The result is target/x86_64-pc-windows-msvc/release/skydek-mp3-encoder.exe.
See README.md for the raw f32LE stdin protocol, arguments and error behavior.
Exit SkyDek DJ before replacing the installed resources/encoder/skydek-mp3-encoder.exe
with your interface-compatible build. Keep a backup of the original executable.
No proprietary application objects or relinking are needed to replace this process.
You may modify and rebuild the helper and its libraries under their own licenses;
reverse engineering needed to debug modifications of those libraries is permitted.
The main app and branding are not covered by this helper source license.

Archive metadata is normalized for repeatable ZIP generation. Exact byte-for-byte
executable reproduction also depends on toolchain, environment and linker versions.
